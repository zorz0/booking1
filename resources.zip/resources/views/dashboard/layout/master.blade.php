@include('dashboard.layout.header')
@include('dashboard.layout.sidebar')
@include('sweetalert::alert')


@yield('content')

</div>
<!-- END CONTENT BODY -->
</div>
<!-- END CONTENT -->

</div>
<!-- END CONTAINER -->
@include('dashboard.layout.footer')
