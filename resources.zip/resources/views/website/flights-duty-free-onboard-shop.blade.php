@extends('website.layout.app')

@section('content')
    Page design 2
@endsection
