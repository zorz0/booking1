<footer id="footer">
    <div class="container">
        <div class="footer-navigation">
            <div class="row dividing_footer_row_new">
                <div class="col-md-3 colmd3">

                    <ul class="footer-menu footer-menu-dark-site">

                        <li><a><strong>&#x639;&#x646; &#x637;&#x64A;&#x631;&#x627;&#x646; &#x627;&#x644;&#x62C;&#x632;&#x64A;&#x631;&#x629;</strong></a></li>
                        <li class="footer_sublist"><a href="/ar-jo/about-us" class="about" data-value="&#x639;&#x646; &#x637;&#x64A;&#x631;&#x627;&#x646; &#x627;&#x644;&#x62C;&#x632;&#x64A;&#x631;&#x629;">&#x639;&#x646; &#x637;&#x64A;&#x631;&#x627;&#x646; &#x627;&#x644;&#x62C;&#x632;&#x64A;&#x631;&#x629;</a></li>
                        <li class="footer_sublist"><a href="/ar-jo/careers" class="about" data-value="&#x627;&#x646;&#x636;&#x645; &#x625;&#x644;&#x649; &#x641;&#x631;&#x64A;&#x642;&#x646;&#x627;">&#x627;&#x646;&#x636;&#x645; &#x625;&#x644;&#x649; &#x641;&#x631;&#x64A;&#x642;&#x646;&#x627;</a></li>
                        <li class="footer_sublist"><a target="_blank" href="/images/sustainability-report-2022_23.pdf?ext=.pdf&_ga=2.150958770.54325688.1686484635-786281965.1684386846&_gac=1.18632299.1684745421.cjwkcajwpayjbhaneiwa-7ena8akofqpqrmka0iux-d9nwaja-eet5_mrynfqhxjcqqtxrb7yhygbxoccygqavd_bwe">&#x627;&#x644;&#x627;&#x633;&#x62A;&#x62F;&#x627;&#x645;&#x629;</a></li>
                        <li class="footer_sublist"><a target="_blank" href="/images/whistleblowing-policy_march-2020-website-upload.pdf?_ga=2.148443953.703476390.1681103742-359242295.1678701834">&#x633;&#x64A;&#x627;&#x633;&#x629; &#x627;&#x644;&#x625;&#x628;&#x644;&#x627;&#x63A;</a></li>

                    </ul>
                </div>
                <div class="col-md-2 colmd3">
                    <ul class="footer-menu footer-menu-dark-site">

                        <li><a><strong>&#x645;&#x646;&#x627;&#x637;&#x642;</strong></a></li>

                        <li class="footer_sublist"><a href="/ar-jo/destinations/africa" class="about" data-value="&#x625;&#x641;&#x631;&#x64A;&#x642;&#x64A;&#x627;">&#x625;&#x641;&#x631;&#x64A;&#x642;&#x64A;&#x627;</a></li>
                        <li class="footer_sublist"><a href="/ar-jo/destinations/asia" class="about" data-value="&#x622;&#x633;&#x64A;&#x627;">&#x622;&#x633;&#x64A;&#x627;</a></li>
                        <li class="footer_sublist"><a href="/ar-jo/destinations/europe" class="about" data-value="&#x623;&#x648;&#x631;&#x648;&#x628;&#x627;">&#x623;&#x648;&#x631;&#x648;&#x628;&#x627;</a></li>
                        <li class="footer_sublist"><a href="/ar-jo/destinations/middle-east" class="about" data-value="&#x627;&#x644;&#x634;&#x631;&#x642; &#x627;&#x644;&#x623;&#x648;&#x633;&#x637;">&#x627;&#x644;&#x634;&#x631;&#x642; &#x627;&#x644;&#x623;&#x648;&#x633;&#x637;</a></li>

                    </ul>
                </div>
                <div class="col-md-2 colmd3">
                    <ul class="footer-menu footer-menu-dark-site">

                        <li><a><strong>&#x627;&#x644;&#x62A;&#x648;&#x627;&#x635;&#x644; &#x645;&#x639;&#x646;&#x627;</strong></a></li>

                        <li class="footer_sublist"><a href="/ar-jo/contact-us" class="about" data-value="&#x627;&#x644;&#x62A;&#x648;&#x627;&#x635;&#x644; &#x645;&#x639;&#x646;&#x627;">&#x627;&#x644;&#x62A;&#x648;&#x627;&#x635;&#x644; &#x645;&#x639;&#x646;&#x627;</a></li>
                        <li class="footer_sublist"><a href="/ar-jo/feedback" class="about" data-value="&#x627;&#x644;&#x627;&#x642;&#x62A;&#x631;&#x627;&#x62D;&#x627;&#x62A;">&#x627;&#x644;&#x627;&#x642;&#x62A;&#x631;&#x627;&#x62D;&#x627;&#x62A;</a></li>
                        <li class="footer_sublist"><a href="{{ route('jazeera-air-cargo') }}" class="about" data-value="&#x627;&#x644;&#x62C;&#x632;&#x64A;&#x631;&#x629; &#x644;&#x644;&#x634;&#x62D;&#x646; &#x627;&#x644;&#x62C;&#x648;&#x64A;">&#x627;&#x644;&#x62C;&#x632;&#x64A;&#x631;&#x629; &#x644;&#x644;&#x634;&#x62D;&#x646; &#x627;&#x644;&#x62C;&#x648;&#x64A;</a></li>
                        <li class="footer_sublist"><a href="/ar-jo/faq" class="about" data-value="&#x627;&#x644;&#x623;&#x633;&#x626;&#x644;&#x629; &#x627;&#x644;&#x634;&#x627;&#x626;&#x639;&#x629;">&#x627;&#x644;&#x623;&#x633;&#x626;&#x644;&#x629; &#x627;&#x644;&#x634;&#x627;&#x626;&#x639;&#x629;</a></li>

                    </ul>
                </div>
                <div class="col-md-2 colmd3">
                    <ul class="footer-menu footer-menu-dark-site">

                        <li><a><strong>&#x627;&#x644;&#x645;&#x631;&#x643;&#x632; &#x627;&#x644;&#x627;&#x639;&#x644;&#x627;&#x645;&#x64A;</strong></a></li>

                        <li class="footer_sublist"><a href="/ar-jo/media-centre/press-release" class="about" data-value="&#x628;&#x64A;&#x627;&#x646; &#x635;&#x62D;&#x641;&#x64A;">&#x628;&#x64A;&#x627;&#x646; &#x635;&#x62D;&#x641;&#x64A;</a></li>
                        <li class="footer_sublist"><a href="/ar-jo/media-centre/media-library" class="about" data-value="&#x645;&#x643;&#x62A;&#x628;&#x629; &#x627;&#x644;&#x648;&#x633;&#x627;&#x626;&#x637;">&#x645;&#x643;&#x62A;&#x628;&#x629; &#x627;&#x644;&#x648;&#x633;&#x627;&#x626;&#x637;</a></li>

                    </ul>
                </div>
                <div class="col-md-3 colmd3">
                    <ul class="footer-menu footer-menu-dark-site">

                        <li><a><strong>&#x627;&#x644;&#x648;&#x62C;&#x647;&#x627;&#x62A; &#x627;&#x644;&#x623;&#x643;&#x62B;&#x631; &#x637;&#x644;&#x628;&#x627;&#x64B;</strong></a></li>

                        <ul class="footer-menu top_destination_class">
                            <li class="footer_sublist"><a href="/ar-jo/flights-to-nepal">&#x646;&#x64A;&#x628;&#x627;&#x644;</a></li>
                            <li class="footer_sublist"><a href="/ar-jo/flights-to-kuwait">&#x627;&#x644;&#x643;&#x648;&#x64A;&#x62A;</a></li>
                            <li class="footer_sublist"><a href="/ar-jo/flights-to-ethiopia">&#x625;&#x62B;&#x64A;&#x648;&#x628;&#x64A;&#x627;</a></li>
                            <li class="footer_sublist"><a href="/ar-jo/flights-to-lebanon">&#x644;&#x628;&#x646;&#x627;&#x646;</a></li>
                        </ul>
                    </ul>

                </div>
            </div>

        </div>

    </div>


    <div class="footer-base">

        <div class="container">

            <a href="{{ route('home') }}" class="brand footer-logo">
                <img src="images/jazeera-logo.png" alt="Jazeera Logo" class="lazyload">
            </a>


            <ul class="single-line-menu">
                <li>
                    <a  href="https://www.facebook.com/Jazeera.Airways/" target="_blank" class="social" data-value="Facebook">
                        <img class="social_media_img lazyload" height="22" width="22" src="/images/sm_facebook.png" alt="facebook">
                    </a>
                </li>
                <li>
                    <a  href="https://www.instagram.com/jazeeraairways/" target="_blank" class="social" data-value="Instagram">
                        <img class="social_media_img lazyload" height="22" width="22" src="/images/sm_insta.png" alt="instagram">
                    </a>
                </li>
                <li>
                    <a  href="https://www.linkedin.com/company/jazeera-airways" target="_blank" class="social" data-value="linkedIn">
                        <img class="social_media_img lazyload" height="22" width="22" src="/images/sm_linkedin.png" alt="linkedin">
                    </a>
                </li>
                <li>
                    <a  href="https://twitter.com/JazeeraAirways" target="_blank" class="social" data-value="twitter">
                        <img class="social_media_img lazyload" height="22" width="22" src="/images/sm_twitter.png" alt="twitter">
                    </a>
                </li>
                <li>
                    <a  href="https://www.youtube.com/channel/UCDZuROfzF_1YPOGjVSdJpLw" target="_blank" class="social" data-value="Youtube">
                        <img class="social_media_img lazyload" height="22" width="22" src="/images/social-icons_youtube.png" alt="youtube">
                    </a>
                </li>
            </ul>

            <ul class="single-line-menu">

                <li><a  href='/ar-jo/terms-and-conditions' class="tps" data-value="Terms and Conditions">&#x627;&#x644;&#x623;&#x62D;&#x643;&#x627;&#x645; &#x648;&#x627;&#x644;&#x634;&#x631;&#x648;&#x637;</a></li>
                <li><a  href='/ar-jo/privacy-policy' class="tps" data-value="Privacy Policy">&#x633;&#x64A;&#x627;&#x633;&#x629; &#x627;&#x644;&#x62E;&#x635;&#x648;&#x635;&#x64A;&#x629;</a></li>
                <li><a  href='/ar-jo/sitemap' class="tps" data-value="Sitemap">&#x62E;&#x631;&#x64A;&#x637;&#x629; &#x627;&#x644;&#x645;&#x648;&#x642;&#x639;</a></li>

            </ul>
            <p>&#xA9; &#x62C;&#x645;&#x64A;&#x639; &#x627;&#x644;&#x62D;&#x642;&#x648;&#x642; &#x645;&#x62D;&#x641;&#x648;&#x638;&#x629; &#x644;&#x637;&#x64A;&#x631;&#x627;&#x646; &#x627;&#x644;&#x62C;&#x632;&#x64A;&#x631;&#x629;&#x60C; 2023.</p>
        </div>
        <a href="#" class="scrollup"> <img class="scoller_image" src="/images/Icon ionic-ios-arrow-down.png" /></a>
    </div>
    <div class="modal" id="custom-alert" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" href="#">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" id="closeButton">

                    </button>
                </div>
                <div class="text-center mb-4" id="sessionTimeOut">
                    &#x627;&#x645;&#x62A;&#x62F;&#x62A; &#x641;&#x62A;&#x631;&#x629; &#x62C;&#x644;&#x633;&#x62A;&#x643; &#x644;&#x645;&#x62F;&#x629; &#x637;&#x648;&#x64A;&#x644;&#x629; &#x648;&#x62A;&#x645; &#x625;&#x644;&#x63A;&#x627;&#x621; &#x62D;&#x62C;&#x632;&#x643;. &#x64A;&#x631;&#x62C;&#x649; &#x627;&#x644;&#x628;&#x62F;&#x621; &#x645;&#x646; &#x62C;&#x62F;&#x64A;&#x62F;.
                </div>
                <div id="SessionStartOverButton">
                    <button class="btn btn-primary d-flex mx-auto mt-3">  &#x627;&#x628;&#x62F;&#x623; &#x645;&#x646; &#x62C;&#x62F;&#x64A;&#x62F;</button>
                </div>
            </div>
        </div>
    </div>



    <div class="modal" id="custom-alert" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" href="#">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" id="closeButton">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="text-center mb-4" id="sessionTimeOut">
                    &#x627;&#x645;&#x62A;&#x62F;&#x62A; &#x641;&#x62A;&#x631;&#x629; &#x62C;&#x644;&#x633;&#x62A;&#x643; &#x644;&#x645;&#x62F;&#x629; &#x637;&#x648;&#x64A;&#x644;&#x629; &#x648;&#x62A;&#x645; &#x625;&#x644;&#x63A;&#x627;&#x621; &#x62D;&#x62C;&#x632;&#x643;. &#x64A;&#x631;&#x62C;&#x649; &#x627;&#x644;&#x628;&#x62F;&#x621; &#x645;&#x646; &#x62C;&#x62F;&#x64A;&#x62F;.
                </div>
                <div id="SessionStartOverButton">
                    <button class="btn btn-primary d-flex mx-auto mt-3">  &#x627;&#x628;&#x62F;&#x623; &#x645;&#x646; &#x62C;&#x62F;&#x64A;&#x62F;</button>
                </div>
            </div>
        </div>
    </div>



    <script>
        function setCookie(cname) {
            var d = new Date();
            //d.setTime(d.getTime() + (10000 * 1000 * 60 * 60 * 24)); //Set the time to exdays from the current date in milliseconds. 1000 milliseonds = 1 second
            d.setTime(d.getTime() + (172800000));
            var expires = "expires=" + d.toGMTString();             //Compose the expirartion date
            window.document.cookie = cname + "=true; " + expires;   //Set the cookie with value and the expiration date
        }

    </script>
    <style>
        .cookies-policy {
            position: fixed;
            bottom: 0;
            width: 100%;
            /*background-color: #082a45;*/
            /*color: #fff;*/
            text-align: center;
            padding: 15px 0;
            z-index: 9999;
            background: #004A97;
            color: #fff;
        }

        .cookies-policy a:link {
            color: #fff;
            text-decoration: underline;
        }

        .btnAgree {
            border-style: solid;
            border-color: white;
            border-width: 2px;
            margin-right: 10px;
            text-decoration: none;
            float: right;
        }
        .destinations_items {
            display: flex;
            flex-wrap: wrap;
        }
        .destinations_items li{
            width: 50%;
        }

        .jazeera_backdrop.active, .jazeera_overlay.active {
            opacity: 0!important;
            visibility: visible!important;
            z-index: 0!important;
        }

        .scrollup {
            display: inline-block;
            width: 40px;
            height: 40px;
            /* opacity: 0.3;*/
            position: fixed;
            bottom: 75px;
            right: 25px;
            z-index: 9;
            display: none;
            /*  text-indent: -9999px;*/
            /*  background-image: url('/assets/images/Icon ionic-ios-arrow-dropup-circle.png');*/
            background-repeat: no-repeat;
            background: #0b97eb !important;
            text-align: center;
            border-radius: 20px;
            line-height: 32px;
            box-shadow: 0 1px 6px rgb(32 33 36 / 8%) !important;
        }

        .scoller_image {
            width: 20px;
        }
        .footer-menu .top_destination_class{
            display: flex;
            flex-wrap: wrap;
        }
        .footer-menu .top_destination_class .footer_sublist{
            flex:50% !important
        }

        .overlay-screen {
            background-color: rgba(0, 0, 0, 0.5); /* Semi-transparent black background */
            position: fixed;
            height: 100%;
            width: 100%;
            top: 0px;
        }
    </style>

</footer>

<!--
<script src="https://mehery.pages.dev/plugins/customer.js">
    { "domain" : "jazeeraairways.mehery.io", "channelId" : "web:www.jazeeraairways.com", "channelKey" : "1gocd3101yw94FVTU7N6BN0", "config" : { "header.bg.color":"#ffffff","header.text.color":"#000000", "header.close.color":"#000ffffff000","header.icon.url":"https://stg-cms.jazeeraairways.com/getattachment/781c850b-47d3-4e0a-a73b-5e6dcfa2b776/jazeera-logo.svg","header.title.text":"Need Help?", "launcher.bg.color":"#0072bc","messageList.bg.color":"#ffffff", "sentMessage.bg.color":"#0167aa","sentMessage.text.color":"#ffffff", "receivedMessage.bg.color":"#009bde","receivedMessage.text.color":"#ffffff", "userInput.bg.color":"#183a8d","userInput.text.color":"#ffffff", "userInput.button.color":"#ffffff" } }
</script>   -->
<script src="https://cdn.moengage.com/webpush/moe_webSdk_webp.min.latest.js?app_id=I2PK50RPVPZZJ5HD2PARXDBI&amp;cluster=DC_2&amp;debug_logs=0"></script>
</div>
<div id="Booking-fixed"></div>






<script>
    function checkAge(age) {
        return age;
    }
    function changeCulture(cultureCode, rawUrl) {

        var locationPath = window.location.href.split('/');
        var domineindex = locationPath.indexOf(window.location.host);
        var culture = locationPath[domineindex + 1];
        if (cultureCode != 'en-US') {
            if (locationPath.length > 5) {
                locationPath[3] = cultureCode;
            }
            else {
                locationPath.splice(3, 0, cultureCode);
                locationPath.splice(4, 1);
            }
            window.location.href = locationPath.join("/");
        } else {
            locationPath.splice(3, 1);
            window.location.href = locationPath.join('');
        }
    }





</script>
<script>
    $(document).ready(function () {
        $(window).scroll(function () {
            if ($(this).scrollTop() > 10) {
                $('.scrollup').fadeIn();
                $(".scrollup").css("display", "inline-block");
            } else {
                $('.scrollup').fadeOut();
            }
        });
        $('.scrollup').click(function () {
            $("html, body").animate({ scrollTop: 0 }, 600);
            return false;
        });
    });
</script>
<script>
    // Create an environment object with properties
    const environmentService = {
        environment: {
            mainDomain: "jazeeraairways.com", // Set the main domain here
            // Add other environment properties here
        },
    };

    // Function to clear a specific cookie by name
    function clearCookieByName(name) {
        document.cookie = name + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; domain=" + environmentService.environment.mainDomain;
    }

    // Function to set a session cookie
    function setSessionCookie() {
        var d = new Date();
        d.setTime(d.getTime() + (15 * 60 * 1000)); // 15 minutes
        var expires = "expires=" + d.toUTCString();
        var domain = "domain=" + environmentService.environment.mainDomain;
        document.cookie = "mySessionCookie=myValue; " + expires + "; path=/; " + domain;
    }

    // Function to log out and redirect
    function showCustomSessionTimeoutAlert() {

        var customAlert = document.getElementById("sessionTimeOut");
        var customAlertOK = document.getElementById("SessionStartOverButton");
        $('#custom-alert').modal({
            backdrop: 'static',
            keyboard: false
        })

        customAlert.style.display = "block";

        customAlertOK.addEventListener("click", function () {
            clearCookieByName("agent_dashboardCookie"); // Clear the "dashboard" cookie
            clearCookieByName("loggedInUser"); // Clear the "loggedInUser" cookie
            window.location.href = "/";
        });
    }

    // Initialize session by setting a session cookie (only if it doesn't exist)
    if (!document.cookie.includes("mySessionCookie=")) {
        setSessionCookie();
    }

    // Initialize session timeout
    var sessionTimeout = 15 * 60000; // 15 minutes

    // Add an event listener to reset session timeout when there is user activity
    var timeoutId;

    function resetSessionTimeout() {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(showCustomSessionTimeoutAlert, sessionTimeout);
    }

    document.addEventListener("mousemove", resetSessionTimeout);
    document.addEventListener("keydown", resetSessionTimeout);

    // Add an event listener to the close button (&times;) to clear the "dashboard" and "loggedInUser" cookies and redirect.
    var closeButton = document.getElementById("closeButton");
    closeButton.addEventListener("click", function () {
        showCustomSessionTimeoutAlert();
    });

    // Add an event listener for the beforeunload event (when the tab/window is closed)
    window.addEventListener("unload", function () {
        showCustomSessionTimeoutAlert();
    });
</script>

<script>
    const currentURL = window.location.href;

    // Check if the URL contains "home?"
    if (currentURL.includes("?Mobile=true")) {
        const elementToHide1 = document.getElementById('header');
        const elementToHide2 = document.getElementById('footer');
        const elementToHide3 = document.getElementById('myChatDiv');
        const elementToHide4 = document.getElementById('Webpopup');

        if (elementToHide1) {
            elementToHide1.style.display = 'none';
            elementToHide3.style.display = 'none';
            elementToHide4.style.display = 'none';

        }
        if (elementToHide2) {
            elementToHide2.style.display = 'none';
            elementToHide3.style.display = 'none';
            elementToHide4.style.display = 'none';
        }
    }
</script>

